export { default as GlobalStyles } from './GlobalStyles';
export { default as theme } from './theme';
