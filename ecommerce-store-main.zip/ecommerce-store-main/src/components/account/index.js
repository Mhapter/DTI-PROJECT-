export { default as ChangePassword } from './ChangePassword';
export { default as EditDetails } from './EditDetails';
