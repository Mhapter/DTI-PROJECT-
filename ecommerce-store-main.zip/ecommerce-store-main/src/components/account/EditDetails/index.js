export { default } from './EditDetails';
