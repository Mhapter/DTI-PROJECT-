export { default } from './ResponsiveBox';
