export { default } from './TopBannerSmall';
