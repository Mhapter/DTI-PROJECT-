export { default } from './StockDisplay';
