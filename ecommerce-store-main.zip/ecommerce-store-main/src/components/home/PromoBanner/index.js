export { default } from './PromoBanner';
