export { default } from './NewsAndProducts';
