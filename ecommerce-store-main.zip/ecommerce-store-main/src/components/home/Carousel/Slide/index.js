export { default } from './Slide';
